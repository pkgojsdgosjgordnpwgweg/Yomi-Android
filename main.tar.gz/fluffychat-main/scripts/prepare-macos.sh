#!/usr/bin/env bash

if ! type "flutter" > /dev/null; then
	brew install flutter
fi

brew install libolm

