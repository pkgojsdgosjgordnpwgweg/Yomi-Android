flutter doctor
flutter config --enable-windows-desktop
flutter clean
flutter pub get

flutter build windows --release -v

