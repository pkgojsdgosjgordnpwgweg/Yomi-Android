#!/usr/bin/env bash

export USER1_NAME="alice"
export USER1_PW="AliceInWonderland"
export USER2_NAME="bob"
export USER2_PW="JoWirSchaffenDas"
