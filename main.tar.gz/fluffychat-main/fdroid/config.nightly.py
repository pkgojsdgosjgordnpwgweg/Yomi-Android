repo_url = "https://fluffychat.im/repo/nightly/repo"
repo_name = "FluffyChat nightly repo"
repo_icon = "fdroid-icon.png"
repo_description = """
FluffyChat nightly repo
"""

archive_older = 0

local_copy_dir = "/fdroid"

keystore = "key.nightly.jks"
repo_keyalias = "vmd66783.contaboserver.net"
