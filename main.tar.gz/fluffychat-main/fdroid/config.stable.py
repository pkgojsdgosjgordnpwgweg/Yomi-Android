repo_url = "https://fluffychat.im/repo/stable/repo"
repo_name = "FluffyChat repo"
repo_icon = "fdroid-icon.png"
repo_description = """
FluffyChat repo
"""

archive_older = 0

local_copy_dir = "/fdroid"

keystore = "key.jks"
repo_keyalias = "key"
