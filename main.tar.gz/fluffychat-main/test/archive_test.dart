import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('Test if the widget can be created', (WidgetTester tester) async {
    /*await tester.pumpWidget(FluffyChatApp(
      testWidget: Archive(),
      testClient: await testClient(loggedIn: true),
    ));*/
  });
}
